<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kidsschool";

$conn = new mysqli($servername, $username, $password, $dbname) ;
// Check connection


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $pincode = $_POST['pincode'];
    $state = $_POST['state'];
    $country = $_POST['country'];

    // Prepare and bind parameters
    $stmt = $conn->prepare("INSERT INTO enquiry (fname , lname , dob , email , mobile , gender , address , city , pincode , state , country ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die("Error: " . $conn->error);
    }

    $stmt->bind_param("ssssisssiss", $fname, $lname, $dob, $email, $mobile, $gender, $address, $city, $pincode, $state, $country);

    // Execute the query
    if ($stmt->execute() === TRUE) {
        header("Location:http://localhost/project/home.html ");
        
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();

?>