<?php

    $host="localhost";
    $user="root";
    $pass= "";
    $dbname="kidsschool";

    $conn=new mysqli($host,$user,$pass,$dbname);

    if($conn->connect_error){
      die("connection failed");
    }


$username=$_POST['username'];
$password=$_POST['password'];

$sql="SELECT * FROM register WHERE username = '$username' AND password ='$password'";

 $result=$conn->query($sql);

 if($result->num_rows>0){
 
    header("Location:http://localhost/project/admission.html" ,true,301);
    exit;
 }
 else{

        header("Location:http://localhost/project/home.html ",true,301);
 }

$conn->close();

?>