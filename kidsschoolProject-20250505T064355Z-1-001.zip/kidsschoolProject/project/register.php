<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kidsschool";

$conn = new mysqli($servername, $username, $password, $dbname) ;


if($conn->connect_error) {
      die("connection failed");
}

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql ="INSERT INTO register (username , password) VALUES ('$username','$password')";

    if($conn->query($sql) == true)
    {
        echo "successfully registration";
        header( "location:http://localhost/project/login.html" );
        exit;
   
    } else {
        echo "error";
    }

  $conn->close();
?>